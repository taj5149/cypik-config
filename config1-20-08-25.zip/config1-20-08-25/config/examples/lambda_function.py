import json
import os
import requests

def handler(event, context):
    print("📌 Incoming Event:", json.dumps(event))

    # Slack webhook URL from environment
    webhook_url = os.environ.get("SLACK_WEBHOOK_URL")
    if not webhook_url:
        print("❌ Missing SLACK_WEBHOOK_URL env variable")
        return {
            "statusCode": 400,
            "body": "❌ SLACK_WEBHOOK_URL not set in environment variables"
        }

    # Default message
    message_text = "🚀 Lambda executed successfully (no SNS payload)."

    # If event came from SNS (AWS Config -> SNS -> Lambda)
    if "Records" in event:
        for record in event["Records"]:
            if record.get("EventSource") == "aws:sns":
                sns_message = record["Sns"]["Message"]
                print("📌 SNS Message:", sns_message)

                # Try to parse Config SNS payload
                try:
                    msg_json = json.loads(sns_message)

                    rule = msg_json.get("configRuleName", "UnknownRule")
                    compliance = (
                        msg_json.get("newEvaluationResult", {})
                        .get("complianceType", "UNKNOWN")
                    )
                    resource = (
                        msg_json.get("newEvaluationResult", {})
                        .get("evaluationResultIdentifier", {})
                        .get("evaluationResultQualifier", {})
                        .get("resourceId", "UnknownResource")
                    )

                    message_text = (
                        f":rotating_light: *AWS Config Rule Triggered!*\n"
                        f"• Rule: *{rule}*\n"
                        f"• Compliance: *{compliance}*\n"
                        f"• Resource: `{resource}`"
                    )
                except Exception as e:
                    print("⚠️ Could not parse SNS JSON:", e)
                    message_text = f":rotating_light: AWS Config Alert:\n```{sns_message}```"

    # Slack payload
    payload = {"text": message_text}

    try:
        response = requests.post(
            webhook_url,
            data=json.dumps(payload),
            headers={"Content-Type": "application/json"},
            timeout=10
        )

        print("📌 Slack Response:", response.status_code, response.text)

        if response.status_code != 200:
            return {
                "statusCode": response.status_code,
                "body": f"Slack API error: {response.text}"
            }

        return {
            "statusCode": 200,
            "body": "✅ Message sent to Slack"
        }

    except Exception as e:
        print("❌ Error sending to Slack:", e)
        return {
            "statusCode": 500,
            "body": f"Error sending to Slack: {e}"
        }
